<html>
  <head>   
  </head>
  <body>
    <form action="pagina2up.php" method="post">
      <input type="text" name="size" placeholder="Filtrar por tamaño..."/>
      <input type ="text" name="color" placeholder="Filtrar por color..."/>
      <br/>
      <input type ="text" name="nombre" placeholder="Nombre a modificar..."/>
     <br/>
      <button>GO!</button>
    </form>
  </body>
</html>