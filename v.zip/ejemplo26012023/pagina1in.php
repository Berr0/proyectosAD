<html>
  <head>   
  </head>
  <body>
    <form action="pagina2in.php" method="post">
       <input type ="text" name="nombre" placeholder="Nombre..."/>
      <input type ="text" name="color" placeholder="color..."/>
      <input type="text" name="size" placeholder="tamaño..."/>

     <br/>
      <button>GO!</button>
    </form>
  </body>
</html>